<div class="container">
    <h1><?php echo e($product->name); ?></h1>

    <div class="row">
        <div class="col-md-6">
            <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid">
        </div>
        <div class="col-md-6">
            <p><strong>Giá:</strong> <?php echo e(number_format($product->price)); ?> VNĐ</p>
            <p><?php echo e($product->description); ?></p>
            <a href="<?php echo e($product->shopee_link); ?>" target="_blank" class="btn btn-primary">Mua trên Shopee</a>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\laravel\shopelk\resources\views/product/show.blade.php ENDPATH**/ ?>